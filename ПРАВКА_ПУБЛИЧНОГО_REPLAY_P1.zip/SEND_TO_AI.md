# Применить готовую правку и закончить настоящий public replay P1

Работай в `Igorr112323/Smarty_Chumakov`, ветка `arena/c5f69767-smarty-chumakov`. Приложен архив **ПРАВКА_ПУБЛИЧНОГО_REPLAY_P1.zip**. Сначала распакуй и прочитай README/CHECKS. Если архива реально нет в доступных файлах — сообщи это один раз, не имитируй его применение.

## Что исправить в предыдущем отчёте

Фразу **«контракт выполнен» убрать**. Подтверждены численные ориентиры answer-метрики на dev в source measurement 39116955685: F1=0,6163522013, FPR=0,1647058824, counts=49/14/47/71. Public replay ещё не завершён, tokens/spans/скорость/поставка и прочие условия отдельно не закрыты.

Run **39135953367** упал на Public replay. Run **39136156232** подтвердил сборку, не воспроизведение предсказаний.

Предположение «нет dev.jsonl/HF setup» не установлено. В проверенном git-дереве dev.jsonl существует, 562 848 Б. На точной копии кода локально воспроизведён другой первый сбой:

```text
ModuleNotFoundError: No module named 'spanverify'
```

Далее обнаружена потеря калибратора: builder пишет в `isotonic` формат `thresholds/values`, но WeightsBundle читает `x/y`. Build возвращает 0, а публичный loader получает `isotonic=None`. Кроме того, replay подставляет `raw_score=calibrated_score` и возвращает success даже при mismatch.

## Готовая правка

База патча — **12e739b872af7b0184222fdebc6f4c8cd120416f**. Проверь актуальный HEAD/working tree. Из корня репозитория:

```bash
git status --short
git apply --check /реальный/путь/01_public_replay.patch
git apply /реальный/путь/01_public_replay.patch
```

Если HEAD изменился — сверить diff и перенести смысл, сохранив новые изменения. Никакого reset/force push. Не заменять исправление урезанной версией или отключением проверок.

Патч затрагивает только engine, builder, replay script, public-replay workflow и новый сквозной test-файл. Не меняет P1-коэффициенты, source artifacts, oof.py, answer_head.py или алгоритм обучения.

Он уже содержит:

- правильный package root для script entrypoints;
- typed assembly/проверку калибратора через публичный WeightsBundle, без неверной схемы JSON;
- проверки замороженных component hashes;
- полный raw_score из публичного forward pass, отдельно от calibrated score;
- lossless runtime float serialization и ошибку на повреждённой P1-head вместо silent fallback;
- точную cache-preflight тем же key helper, что Verifier, без свежего HF backend;
- по-ID сравнение всех пар с reference и с результатом после save/load;
- ненулевой exit при несоответствии scores/predictions/метрик;
- all_family_metrics для одного реально загруженного кандидата;
- рекурсивную раскладку 8 кеш-шардов, явные permissions и публикацию outputs/логов даже при failure.

## Проверки и запуск

Локально у правки **75 passed**, ruff/black/py_compile и git apply/diff checks успешны. Это **целевые тесты Python 3.13**, не весь suite, не новый real-HF quality-run. Сквозной unit replay использует искусственную FeatureMatrix. Один builder-test использует настоящие frozen P1-параметры и проверяет их неизменность.

Подтверди тесты на штатном CI. Команды есть в README. Затем обычный commit/push **без [skip ci] в запускающем коммите**. Новый public-replay workflow автоматически выполнит дешёвый cached replay; полного P1-обучения и precompute он не запускает.

Не добавлять dev.jsonl в artifact «для лечения» найденной ошибки — использовать существующий явно заданный `--dev`. Не устанавливать новый HF backend/веса вместо проверки cache completeness. При несовместимом/пустом кеше должна быть ясная ошибка до fresh inference.

## Что нужно подтвердить на настоящих 181 dev-парах

Сохранённая P1 и исходный threshold **0,5794392523364486** неизменны. После публичного forward pass и reload ожидается reference **TP=49, FP=14, FN=47, TN=71**, F1=0,6163522013, FPR=0,1647058824.

Это reference для проверки, а не значения для записи вместо вычисления. Любое отличие объяснять по per-pair raw/calibrated/feature state; **модель, labels и threshold не подгонять**.

Нужны:

1. `reference_parity.matched=true` и `roundtrip_parity.matched=true`, реальные 0 mismatches по ID, raw/calibrated score, threshold и answer prediction.
2. Корректные raw AUC≈0,7321078431 и calibrated AUC≈0,7338235294, не подмена одного другим.
3. Реальный `Verifier.evaluate()` для tokens/spans/answers/verdicts того же кандидата. Старые token/span метрики не переносить как новые.
4. Загружаемый bundle, runtime config, public_replay.jsonl, score_parity_report.json, all_family_metrics.json, runtime manifest и логи.
5. Публикация в отдельном каталоге `spanverify-module/reports/experiments/p1_public_replay/run<actual_run_id>/` с настоящим replay run/SHA и report commit отдельно от source measurement b878507.

Если mismatches/ошибка — workflow остаётся failure, диагностические файлы всё равно публикуются. Прочитай их и исправь конкретную причину, не возвращай «вероятно отсутствуют данные».

## Следующий ответ пользователю

- Точный новый public-replay run ID, commit и статус.
- Реально пересчитанные F1/FPR/TP/FP/FN/TN, raw/calibrated AUC и количество несовпадений.
- Результат save/load и подтверждение, что calibrator загружен, не None.
- Все metric families одного кандидата, какие ниже нормы.
- Ссылки на сохранённые bundle/config/evidence/manifest/log, фактические размеры.
- Статус полного CI отдельно от scoped tests.

**Не считать успешный build заменой replay.** Не писать «контракт выполнен» по одной answer-метрике на dev. Official test, новое обучение P1, корпус A и 16 precompute-шардов в этой задаче не запускать. Пользователь код/команды локально не выполняет.
