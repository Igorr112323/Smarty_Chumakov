# Готовая правка public replay P1 — база 12e739b

Репозиторий `Igorr112323/Smarty_Chumakov`, ветка `arena/c5f69767-smarty-chumakov`.
Базовая ревизия: **12e739b872af7b0184222fdebc6f4c8cd120416f**.

## Найденные реальные ошибки

1. `replay_p1_dev.py` при запуске обычной командой из workflow не добавляет корень Python-пакета. Воспроизведён **ModuleNotFoundError: No module named 'spanverify'** — до чтения dev. Сам `data/corpus_a3/splits/dev.jsonl` в проверенном git-дереве существует, размер 562 848 Б. Добавление dev в артефакт не исправляет эту ошибку.
2. Builder записывает `isotonic={thresholds, values, meta}`, но `WeightsBundle.from_dict()` читает `isotonic={x,y}`. Файл создаётся успешно, однако загруженный `bundle.isotonic` оказывается None. Это потерянная калибровка, которую прежний build-test не ловил.
3. Replay заменяет настоящий raw score на calibrated score; raw AUC при этом не является raw AUC.
4. Replay печатает mismatch, но возвращает exit 0 и не сравнивает все пары по ID.
5. Сериализация `WeightsBundle` округляет runtime-параметры и может менять решения у границы.

## Что исправлено

Изменяются **ровно 5 файлов**:

- `spanverify-module/spanverify/engine.py`;
- `spanverify-module/scripts/build_p1_candidate.py`;
- `spanverify-module/scripts/replay_p1_dev.py`;
- `.github/workflows/p1-public-replay.yml`;
- новый `spanverify-module/tests/test_p1_replay_contract.py`.

Новая реализация:

- корректный package path для обоих entrypoints;
- сборка через публичные WeightsBundle/IsotonicCalibrator, с проверкой реальной загрузки калибратора;
- SHA-256 четырёх замороженных исходных файлов проверяются до сборки; допускается только Git LF→CRLF материализация JSON на Windows, при этом отдельно сохраняются source-LF и фактические checkout hashes; изменения численных параметров отвергаются;
- отдельный runtime config с mode/model/window/chunking/span strategy;
- сохранение полных float, включая threshold и isotonic x/y;
- `stats['raw_score_full']` даёт настоящий неокруглённый raw answer score; legacy `raw_score` остаётся форматированным;
- повреждённая заданная P1-head не превращается в молчаливый legacy fallback;
- dev-path указан явно, есть проверка cache coverage тем же key helper и параметрами, что движок;
- отсутствие нужных cached features — ошибка до backend, а не новый HF-инференс;
- до/после reload выполняется настоящий публичный `Verifier.verify()` на всех парах;
- сравниваются IDs, gold, raw/calibrated scores, thresholds, predictions и пересчитанные метрики;
- mismatch даёт ненулевой exit, при этом JSONL и parity report сохраняются;
- `Verifier.evaluate()` измеряет все token/span/answer/verdict families одного кандидата;
- workflow включает fast regression перед replay, рекурсивную раскладку 8 шардов, явные actions/content permissions, публикацию логов даже при failure и обычный push из свежего worktree без force push.

**Не меняются** P1-коэффициенты/скейлер/порог/калибратор, answer_head.py, oof.py, обучение и исходные frozen artifacts. Нового OOF/обучения или precompute в replay нет. Работа идёт на существующем A3-кеше source run 39060670054.

## Применение coding-агентом

Из корня репозитория:

```bash
git status --short
git apply --check /путь/к/01_public_replay.patch
git apply /путь/к/01_public_replay.patch
```

Не использовать reset/force push и не перетирать новые изменения. Если HEAD изменился — проверить diff и перенести правки, сохранив реальные tests/guards.

После применения:

```bash
cd spanverify-module
python -m pytest -q \
  tests/test_calibration_fix.py tests/test_oof_protocol.py \
  tests/test_answer_label.py tests/test_gold_counts.py \
  tests/test_oof_public_pipeline.py tests/test_answer_head.py \
  tests/test_p1_integration.py tests/test_p1_replay_contract.py
```

Затем ruff/black, полный suite/CI по реальным результатам и обычный commit/push. Не ставить `[skip ci]` в запускающем коммите. Изменённый public-replay workflow запускается автоматически; эти файлы не входят в триггер полного P1-обучения. Если уже есть совместимый replay-run, не создавать дубликат без проверки.

## Проверено локально

- **75 passed**, Python 3.13: прежние 62 целевых теста + 13 новых cases.
- Реальный frozen P1 builder запущен через subprocess из чужой cwd без PYTHONPATH; исходные четыре файла не изменены.
- Публичный loader сохранил исходные thresholds/values и полный threshold.
- CLI replay с пустым кешем падает понятной cache-ошибкой, а не ModuleNotFoundError.
- Сквозной mode=hf replay на **искусственной FeatureMatrix/cache fixture** прошёл до/после reload и создал все family metrics без backend.
- Raw и calibrated значения различаются и проверяются отдельно.
- Whole-bundle near-threshold regression сохраняет предсказание; corrupted head отвергается.
- Ruff/black/py_compile изменённых Python-файлов — успешно.
- YAML и bash-синтаксис workflow — проверены.
- `git apply --check` и применение патча в отдельном git-каталоге — проверены; файлы совпадают с подготовленными.

## Честные ограничения

**Это не весь suite и не реальный replay 181 HF-пары в этой песочнице.** Полный настоящий A3-feature cache скачивается на runner. Искусственный cache в unit test — только проверка кода, не качество HF.

На source run **39116955685 @ b878507** уже независимо подтверждены answer F1=0,6163522013, FPR=0,1647058824, TP/FP/FN/TN=49/14/47/71. Теперь runner должен воспроизвести это публичным API. Эти числа не подставляются в выход патчем: reference читается из исходного JSONL, actual считается кодом.

`passed` в parity report означает совпадение исполнения с reference, **не закрытие всего договора**. Все family metrics измеряются отдельно; качество tokens/spans может оставаться ниже нормы. Исторический internal gate 0,90/0,10 не является договорным 0,50/0,40.

Холодный HF-инференс/скорость 2 млн знаков этим cached replay не измеряется. Official test не используется. Новый научный алгоритм, обучение/ретюнинг модели и baseline OOF-refactor не входят в эту узкую правку.

GitHub-репозиторий этим помощником не изменён, новый replay на GitHub здесь не запускался. Применить патч и показать фактический run должен coding-агент.
